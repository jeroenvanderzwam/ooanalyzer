
// Dump P-Code at various levels.
//@author Jeff Gennari <jsg@cert.org>
//@category CERT.Analysis
//@classification UNCLASSIFIED

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import ghidra.app.decompiler.ClangLine;
import ghidra.app.decompiler.ClangToken;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.decompiler.component.DecompilerUtils;
import ghidra.app.script.GhidraScript;
import ghidra.program.disassemble.Disassembler;
import ghidra.program.flatapi.FlatProgramAPI;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.pcode.HighConstant;
import ghidra.program.model.pcode.HighFunction;
import ghidra.program.model.pcode.HighLocal;
import ghidra.program.model.pcode.HighOther;
import ghidra.program.model.pcode.HighVariable;
import ghidra.program.model.pcode.PcodeBlock;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.pcode.PcodeOpAST;
import ghidra.program.model.pcode.Varnode;
import ghidra.program.model.pcode.VarnodeAST;
import ghidra.program.model.scalar.Scalar;
import ghidra.util.exception.CancelledException;

public class ListPCode extends GhidraScript {

	private DecompInterface setUpDecompiler() {

		DecompInterface decompInterface = new DecompInterface();

		// call it to get results
		if (!decompInterface.openProgram(currentProgram)) {
			printerr("Decompile Error: " + decompInterface.getLastMessage());
			return null;
		}

		
		return decompInterface;
	}

	private DecompileResults decompileFunction(Function f, DecompInterface decompiler) {
		return decompiler.decompileFunction(f, 30, monitor);
	}

	/**
	 * This is the function that emits p-code for decompiler statements
	 * 
	 * @param set
	 * @throws CancelledException
	 */
	private void listDecompilerPcode(AddressSetView set) throws CancelledException {

		HashMap<ClangLine, List<PcodeOpAST> > line2Pcode = new HashMap<>();
		DecompInterface decompiler = setUpDecompiler();
		Address addr = askAddress("Function address", "Which function address");
		Function func = new FlatProgramAPI(currentProgram).getFunctionContaining(addr);
		if (func != null) {
			DecompileResults decompResult = decompileFunction(func, decompiler);

			// High-level abstraction associated with a low level function made up of
			// assembly instructions. Based on information the decompiler has produced after
			// working on a function.

			HighFunction hFunc = decompResult.getHighFunction();
			Iterator<PcodeOpAST> pcodeIter = hFunc.getPcodeOps();
				
			
			println("HighFunction P-Code: ");
			pcodeIter = hFunc.getPcodeOps();
			pcodeIter.forEachRemaining(p -> println(toString(p)));
			println("=====");

			ArrayList<ClangLine> lines = DecompilerUtils.toLines(decompResult.getCCodeMarkup());
			lines.forEach(l -> {

				// For each line get the tokens and determine if the p-code associated with any
				// token is the same as the high function p-code save it

				List<ClangToken> tokens = l.getAllTokens();
				for (var tok : tokens) {					
					PcodeOpAST tokPcode = (PcodeOpAST) tok.getPcodeOp();
					if (tokPcode != null) {
						Address tokAddr = tokPcode.getSeqnum().getTarget();
						
						// Fetch all the pcode associated with this token address
						Iterable<PcodeOpAST> iterable = () -> hFunc.getPcodeOps(tokAddr);   
				        List<PcodeOpAST> pcodeList = StreamSupport.stream(iterable.spliterator(), false).collect(Collectors.toList());
						
				        if (pcodeList != null) {
							if (!pcodeList.isEmpty() && line2Pcode.containsKey(l)) {
								List<PcodeOpAST> existingPcode = line2Pcode.get(l);
								existingPcode.addAll(pcodeList);

							}
							line2Pcode.put(l, pcodeList);
						}
					}
				}
			});

			StringBuffer out = new StringBuffer();
			
			for(Map.Entry<ClangLine, List<PcodeOpAST>> entry : line2Pcode.entrySet()) {
			    ClangLine line = entry.getKey();
			    List<PcodeOpAST> pcodes = entry.getValue();
			    
				out.append("---\nClang line: " + line.toString() + "\n");
				for (var pc : pcodes)
					out.append(toString(pc));
			}
			println("===\n" + out.toString());

		} else {
			printerr("There is no function associated with address: " + addr.toString());
		}
	}

	private String toString(PcodeOpAST pcode) {

		StringBuffer buffer = new StringBuffer("");
		if (pcode != null) {
			PcodeBlock bb = pcode.getParent();
            
			buffer.append("P-code: " + pcode.toString() + " @ " + pcode.getSeqnum().getTarget() + "\n");

			buffer.append("Varnode Inputs: ");
			Varnode[] vin = pcode.getInputs();
			
			if (vin != null && vin.length > 0) {

				Arrays.stream(vin).forEach(v -> {
					
					VarnodeAST vinAst = (VarnodeAST) v;
					buffer.append("Unique ID: " + String.valueOf(vinAst.getUniqueId()));
					HighVariable hv = vinAst.getHigh();
					if (hv != null) {
						buffer.append(", " + toString(hv) + "\n");
					} else {
						buffer.append(", " + vinAst.toString(currentProgram.getLanguage()) + "\n");
					}
				});
			}

			// buffer.append("Varnode Outputs: ");
			VarnodeAST voutAst = (VarnodeAST) pcode.getOutput();
			
			if (voutAst != null) {
				buffer.append("Unique ID: " + String.valueOf(voutAst.getUniqueId()));
				HighVariable hv = voutAst.getHigh();
				if (hv != null) {
					buffer.append(", " + toString(hv));
				} else {
					buffer.append(", " + voutAst.toString(currentProgram.getLanguage()));
				}
			}
			buffer.append("\n-----\n");
		}
		return buffer.toString();
	}

	private String toString(HighVariable highVariable) {

		StringBuffer buf = new StringBuffer();

		buf.append("Name: " + highVariable.getName() + ", Size: "
				+ highVariable.getSize() + ", Type: " + highVariable.getDataType().getName());

		if (highVariable instanceof HighLocal) {
			HighLocal highLocal = (HighLocal) highVariable;
			buf.append(", Local: " + highLocal.getSymbol().getHighVariable());
		} else if (highVariable instanceof HighConstant) {
			HighConstant highConst = (HighConstant) highVariable;
			Scalar val = highConst.getScalar();
			buf.append(", Const value: " + val.toString());
		} else if (highVariable instanceof HighOther) {
			HighOther highOther = (HighOther) highVariable;
			Varnode vn = highOther.getRepresentative();

			if (vn.isConstant()) {
				buf.append(", Other " + vn.toString());
			}

		}
		return buf.toString();

	}

	/**
	 * This is really easy because p-code is attached to instructions
	 * 
	 * @param set
	 * @throws CancelledException
	 */
	private void listDisassmblerPcode(AddressSetView set) throws CancelledException {

		if (set == null || set.isEmpty()) {
			set = currentProgram.getMemory().getExecuteSet();
		}
		Disassembler.clearUnimplementedPcodeWarnings(currentProgram, set, monitor);

		int completed = 0;
		monitor.initialize(set.getNumAddresses());

		InstructionIterator instructions = currentProgram.getListing().getInstructions(set, true);
		while (instructions.hasNext()) {
			monitor.checkCanceled();
			Instruction instr = instructions.next();

			PcodeOp[] pcode = instr.getPcode();

			println("Instruction: " + instr.toString() + " has the following P-Codes/Varnodes");

			for (int i = 0; i < pcode.length; i++) {
				println("   P[" + i + "]: " + pcode[i].toString());
				Varnode[] vnode = pcode[i].getInputs();
				for (int j = 0; j < vnode.length; j++) {
					println(vnode[j].toString(currentProgram.getLanguage()));
				}
			}

			completed += instr.getLength();
			if ((completed % 1000) == 0) {
				monitor.setProgress(completed);
			}
		}
	}

	@Override
	protected void run() throws Exception {
		if (currentProgram == null) {
			return;
		}

		try {
			String choice = askChoice("Choose P-Code", "Please choose  P-Code level", new ArrayList<String>() {
				{
					add("Disassembler");
					add("Decompiler");
					add("Both");
				}
			}, "Both");
			if (choice.equalsIgnoreCase("Disassember")) {
				println("===================================\nDISASSEMBLER:\n===================================");
				listDisassmblerPcode(currentSelection);
			} else if (choice.equalsIgnoreCase("Decompiler")) {
				println("===================================\nDECOMPILER:\n===================================");
				listDecompilerPcode(currentSelection);
			} else {
				println("===================================\nDISASSEMBLER:\n===================================");
				listDisassmblerPcode(currentSelection);
				println("===================================\nDECOMPILER:\n===================================");
				listDecompilerPcode(currentSelection);
			}
		} catch (CancelledException cx) {
		}
	}

}
